<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Tukang extends Authenticatable
{
    //
}
