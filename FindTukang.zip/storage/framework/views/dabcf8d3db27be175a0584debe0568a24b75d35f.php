<?php $__env->startSection('title'); ?>
    FindTukang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-md-center">
            <div>
                <div class="jumbotron jumbotron-fluid">
                    <div class="container text-center">
                        <h1 class="display-4">Find Tukang</h1>
                        <p class="lead">with us, make your work easier and simpler</p>
                        <form class="form-inline col" action="<?php echo e(URL('/tukang/search')); ?>" method="get">
                            <?php echo e(csrf_field()); ?>

                            <input class="form-control mr-sm-2 col" name="search" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-info my-2 my-sm-0" type="submit">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </button>
                        </form>
                    </div>
                </div>

                <br>
                <div class="card-deck">
                    <?php foreach($tukangs as $tukang): ?>
                        <div class="card col-md-4">
                            <div class="card-header">
                                <p class="text-center"><?php echo e($tukang->city); ?></p>
                            </div>
                            <img class="card-img-top" src="<?php echo e(URL('/tukang/image/'.$tukang->picture)); ?>" alt="Card image cap">
                            <div class="card-body">
                                <p class="card-title text-center"><?php echo e($tukang->name); ?></p>
                                <hr>
                                <div class="d-flex">
                                    <?php if($tukang->status == 'Available'): ?>
                                        <p class="card-subtitle mr-auto text-success">Available</p>
                                        <p class="card-subtitle ml-auto text-muted">Booked</p>
                                    <?php else: ?>
                                        <p class="card-subtitle mr-auto text-muted">Available</p>
                                        <p class="card-subtitle ml-auto text-warning">Booked</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if(Auth::guard('web')->check()): ?>
                                <div class="card-footer">
                                    <form action="<?php echo e(URL('/booking/'.$tukang->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('put')); ?>

                                        <?php if($tukang->status == 'Booked'): ?>
                                            <button type="submit" class="btn btn-block btn-secondary" disabled>Booking</button>
                                        <?php else: ?>
                                            <button type="submit" class="btn btn-block btn-primary">Booking</button>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <ul class="pagination">
                    <?php echo e($tukangs->render()); ?>

                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>