@extends('layouts.master')

@section('title')

@endsection

@section('content')

@endsection

@section('script')

@endsection